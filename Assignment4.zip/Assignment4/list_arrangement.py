#!/usr/bin/env python
# coding: utf-8

# In[4]:


#Section 1
word="AcadGild"
#list Comprehension
output_list=[w.upper() for w in list(word)]
print("Output:")
print(output_list)

#Section 2
word_1=list('xyz')
word_2=[x*n for x in word_1 for n in range(1,5) ]
print(word_2)

#Section 3
word_3=[x*n for n in range(1,5) for x in word_1 ]
print(word_3)

#Section 4
number=[2,3,4]
number_1=[[x+n] for x in number for n in range(0,3)]
print(number_1)

#Section 5
number_2=[2,3,4,5]
number_3=[[x+n for n in range(0,4)] for x in number_2 ]
print(number_3)

#Section 6
number_4=[1,2,3]
number_5= [(b,a) for a in number_4 for b in number_4]
print(number_5)


# In[ ]:




