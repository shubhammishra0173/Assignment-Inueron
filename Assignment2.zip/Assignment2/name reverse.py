#!/usr/bin/env python
# coding: utf-8

# In[1]:


firstname = input("Input your First Name : ")
lastname = input("Input your Last Name : ")
print ( lastname + " " + firstname)


# In[ ]:




