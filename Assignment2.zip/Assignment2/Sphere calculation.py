#!/usr/bin/env python
# coding: utf-8

# In[1]:


import math
pi = math.pi
r = float(12)
V = (float(4/3)*(pi)*(r)**3)
print(V)
          


# In[ ]:




